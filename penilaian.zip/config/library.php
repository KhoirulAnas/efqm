<?php 
date_default_timezone_set('Asia/Jakarta'); // PHP 7 mengharuskan penyebutan timezone.         
$tgl_sekarang = date("Y-m-d");
$thn_sekarang = date("Y");
$jam_sekarang = date("H:i:s");
$datetime = date("Y-m-d H:i:s");    
?>
