 <!--DASHBOARD-->
	<li class='<?php echo"$h_active"; ?>'><a href='home'><i class='menu-icon fa fa-home'></i><span class='menu-text'> Home </span></a><b class='arrow'></b></li>
  
	<!--Laporan-->
    <li class="<?php echo"$laporan_active_open"; ?>"><a href="#" class="dropdown-toggle"><i class="menu-icon fa fa-bar-chart-o"></i><span class="menu-text"> Laporan </span><b class="arrow fa fa-angle-down"></b></a>
    <b class="arrow"></b>
    <ul class="submenu">
	<li class="<?php echo"$laporan_laporan_active"; ?>"><a href="report-transaksi"><i class="menu-icon fa fa-caret-right"></i>Laporan</a><b class="arrow"></b></li>
    </ul>
    </li>
  