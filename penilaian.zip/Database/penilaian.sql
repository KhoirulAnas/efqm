-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 06:37 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penilaian`
--

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` varchar(7) NOT NULL,
  `nama_karyawan` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `id_tahun_penilaian_aktif` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `alamat`, `id_tahun_penilaian_aktif`) VALUES
('K001', 'Katrungan', 'Jl. Kyai Mojo No.202, Bakalan, Katrungan, Kec. Krian, Kabupaten Sidoarjo', 'TA004'),
('K002', 'Ponokawan', 'RT.06 RW.12 Krian, Jl. Raya Ponokawan, Karangpoh, Ponokawan, Sidoarjo, ', 'TA004'),
('K003', 'Sidoklumpuk', 'Jl. Kartini No.67, Sidoklumpuk, Sidokumpul, Kec. Sidoarjo, Kabupaten Sidoarjo', 'TA004');

--
-- Triggers `karyawan`
--
DELIMITER $$
CREATE TRIGGER `before_delete_karyawan` BEFORE DELETE ON `karyawan` FOR EACH ROW BEGIN

DELETE FROM mutasi WHERE mutasi.id_karyawan=OLD.id_karyawan;
DELETE FROM transaksi WHERE transaksi.id_karyawan=OLD.id_karyawan;
  
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` varchar(7) NOT NULL,
  `nama_kategori` varchar(200) NOT NULL,
  `bobot` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `bobot`) VALUES
('KR001', 'People', 20),
('KR002', 'Customer Results', 20),
('KR003', 'Business Results', 20),
('KR004', 'Partnership &amp; Resources', 20),
('KR005', 'Process, Product &amp; Services', 20);

--
-- Triggers `kategori`
--
DELIMITER $$
CREATE TRIGGER `after_delete_kategori` AFTER DELETE ON `kategori` FOR EACH ROW DELETE FROM transaksi WHERE id_kategori=OLD.id_kategori
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kompetensi`
--

CREATE TABLE `kompetensi` (
  `id_kompetensi` varchar(7) NOT NULL,
  `id_kategori` varchar(20) NOT NULL,
  `nama_kompetensi` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kompetensi`
--

INSERT INTO `kompetensi` (`id_kompetensi`, `id_kategori`, `nama_kompetensi`) VALUES
('KO001', 'KR001', 'Meeting untuk menjalin komunikasi antar pegawai'),
('KO002', 'KR001', 'Pelatihan pada pegawai sebagai langkah mengembangkan kualitas SDM'),
('KO003', 'KR001', 'Penerapan SOP pada absensi pegawai'),
('KO004', 'KR002', 'Adanya sistem feedback Pelanggan'),
('KO005', 'KR002', 'Stabilitas jumlah pelanggan'),
('KO006', 'KR002', 'Sistem bonus atau diskon bagi pembeli yang berlangganan'),
('KO007', 'KR003', 'Stabilitas Pendapatan Penjualan'),
('KO008', 'KR003', 'Pengeluaran bulanan tidak melebihi pemasukan'),
('KO009', 'KR003', 'Pendapatan penjualan dari pemesanan online'),
('KO010', 'KR004', 'Dokumen Kontrak dengan Supplier'),
('KO011', 'KR004', 'Adanya rencana anggaran yang disiapkan untuk sumber daya Perusahaan'),
('KO012', 'KR004', 'Adanya Tata kelola keuangan untuk menjaga kondisi finansial perusahaan agar lebih baik'),
('KO013', 'KR005', 'Sistem kasir untuk memudahkan penjualan'),
('KO014', 'KR005', 'Pencatatan akuntansi terkomputerisasi'),
('KO015', 'KR005', 'Keaktifan marketing media sosial untuk promosi produk dan layanan');

--
-- Triggers `kompetensi`
--
DELIMITER $$
CREATE TRIGGER `after_update_kompetensi` AFTER UPDATE ON `kompetensi` FOR EACH ROW UPDATE transaksi SET id_kategori=NEW.id_kategori WHERE id_kategori=OLD.id_kategori
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id_level` int(3) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id_level`, `level`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `mutasi`
--

CREATE TABLE `mutasi` (
  `id` int(5) NOT NULL,
  `id_tahun_penilaian` varchar(10) NOT NULL,
  `id_karyawan` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mutasi`
--

INSERT INTO `mutasi` (`id`, `id_tahun_penilaian`, `id_karyawan`) VALUES
(19, 'TA001', 'K001'),
(20, 'TA002', 'K001'),
(21, 'TA001', 'K002'),
(22, 'PP001', 'K003'),
(23, 'PP002', 'K003'),
(24, 'PP003', 'K003'),
(25, 'PP001', 'K002'),
(26, 'PP002', 'K002'),
(27, 'PP003', 'K002'),
(28, 'PP003', 'K001'),
(29, 'PP002', 'K001'),
(30, 'PP001', 'K001'),
(31, 'TA004', 'K003'),
(32, 'TA004', 'K002'),
(33, 'TA004', 'K001');

--
-- Triggers `mutasi`
--
DELIMITER $$
CREATE TRIGGER `after_delete_mutasi` AFTER DELETE ON `mutasi` FOR EACH ROW BEGIN

DELETE FROM transaksi WHERE transaksi.id_karyawan=OLD.id_karyawan AND id_tahun_penilaian=OLD.id_tahun_penilaian;
  
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_mutasi` AFTER INSERT ON `mutasi` FOR EACH ROW INSERT INTO transaksi (id_karyawan,id_kategori,id_kompetensi,id_tahun_penilaian)
SELECT (NEW.id_karyawan),id_kategori,id_kompetensi,(NEW.id_tahun_penilaian) FROM kompetensi
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_insert_mutasi` BEFORE INSERT ON `mutasi` FOR EACH ROW UPDATE karyawan SET id_tahun_penilaian_aktif=NEW.id_tahun_penilaian WHERE id_karyawan=NEW.id_karyawan
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id_rating` varchar(7) NOT NULL,
  `nilai_rating` varchar(10) NOT NULL,
  `keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id_rating`, `nilai_rating`, `keterangan`) VALUES
('TA001', '1', 'Not Achieved / Tidak Tercapai'),
('TA002', '2', 'Partially Achieved / Tercapai Sebagian'),
('TA003', '3', 'Achieved / Tercapai'),
('TA004', '4', 'Partially Exceeded / Tercapai Lebih'),
('TA005', '5', 'Consistently Exceeded / Selalu Tercapai Lebih');

-- --------------------------------------------------------

--
-- Table structure for table `tahun_penilaian`
--

CREATE TABLE `tahun_penilaian` (
  `id_tahun_penilaian` varchar(7) NOT NULL,
  `nama_tahun_penilaian` varchar(20) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tahun_penilaian`
--

INSERT INTO `tahun_penilaian` (`id_tahun_penilaian`, `nama_tahun_penilaian`, `keterangan`) VALUES
('PP001', 'Januari 2021', '-'),
('PP002', 'Februari 2021', '-'),
('PP003', 'Maret 2021', '-'),
('TA004', 'April 2021', '-');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(5) NOT NULL,
  `id_karyawan` varchar(10) NOT NULL,
  `id_kategori` varchar(10) NOT NULL,
  `id_kompetensi` varchar(10) NOT NULL,
  `id_tahun_penilaian` varchar(10) NOT NULL,
  `rating` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_karyawan`, `id_kategori`, `id_kompetensi`, `id_tahun_penilaian`, `rating`) VALUES
(324, 'K003', 'KR001', 'KO001', 'TA004', '5'),
(325, 'K003', 'KR001', 'KO002', 'TA004', '4'),
(326, 'K003', 'KR001', 'KO003', 'TA004', '3'),
(327, 'K003', 'KR002', 'KO004', 'TA004', '4'),
(328, 'K003', 'KR002', 'KO005', 'TA004', '5'),
(329, 'K003', 'KR002', 'KO006', 'TA004', '3'),
(330, 'K003', 'KR003', 'KO007', 'TA004', '5'),
(331, 'K003', 'KR003', 'KO008', 'TA004', '5'),
(332, 'K003', 'KR003', 'KO009', 'TA004', '2'),
(333, 'K003', 'KR004', 'KO010', 'TA004', '3'),
(334, 'K003', 'KR004', 'KO011', 'TA004', '4'),
(335, 'K003', 'KR004', 'KO012', 'TA004', '3'),
(336, 'K003', 'KR005', 'KO013', 'TA004', '2'),
(337, 'K003', 'KR005', 'KO014', 'TA004', '3'),
(338, 'K003', 'KR005', 'KO015', 'TA004', '3'),
(339, 'K002', 'KR001', 'KO001', 'TA004', '5'),
(340, 'K002', 'KR001', 'KO002', 'TA004', '4'),
(341, 'K002', 'KR001', 'KO003', 'TA004', '3'),
(342, 'K002', 'KR002', 'KO004', 'TA004', '4'),
(343, 'K002', 'KR002', 'KO005', 'TA004', '5'),
(344, 'K002', 'KR002', 'KO006', 'TA004', '3'),
(345, 'K002', 'KR003', 'KO007', 'TA004', '5'),
(346, 'K002', 'KR003', 'KO008', 'TA004', '5'),
(347, 'K002', 'KR003', 'KO009', 'TA004', '3'),
(348, 'K002', 'KR004', 'KO010', 'TA004', '3'),
(349, 'K002', 'KR004', 'KO011', 'TA004', '2'),
(350, 'K002', 'KR004', 'KO012', 'TA004', '3'),
(351, 'K002', 'KR005', 'KO013', 'TA004', '2'),
(352, 'K002', 'KR005', 'KO014', 'TA004', '2'),
(353, 'K002', 'KR005', 'KO015', 'TA004', '1'),
(354, 'K001', 'KR001', 'KO001', 'TA004', '3'),
(355, 'K001', 'KR001', 'KO002', 'TA004', '4'),
(356, 'K001', 'KR001', 'KO003', 'TA004', '3'),
(357, 'K001', 'KR002', 'KO004', 'TA004', '4'),
(358, 'K001', 'KR002', 'KO005', 'TA004', '4'),
(359, 'K001', 'KR002', 'KO006', 'TA004', '3'),
(360, 'K001', 'KR003', 'KO007', 'TA004', '4'),
(361, 'K001', 'KR003', 'KO008', 'TA004', '5'),
(362, 'K001', 'KR003', 'KO009', 'TA004', '3'),
(363, 'K001', 'KR004', 'KO010', 'TA004', '3'),
(364, 'K001', 'KR004', 'KO011', 'TA004', '2'),
(365, 'K001', 'KR004', 'KO012', 'TA004', '3'),
(366, 'K001', 'KR005', 'KO013', 'TA004', '2'),
(367, 'K001', 'KR005', 'KO014', 'TA004', '3'),
(368, 'K001', 'KR005', 'KO015', 'TA004', '4');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` varchar(10) NOT NULL,
  `nama_user` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` enum('admin','user') NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `username`, `password`, `level`) VALUES
('US000', 'Administrator', 'admin', '123456', 'admin'),
('US0000', 'User', 'user', '123456', 'user'),
('US001', 'Alvaaro Al Kahfi', 'alvaro', 'alvaro', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `kompetensi`
--
ALTER TABLE `kompetensi`
  ADD PRIMARY KEY (`id_kompetensi`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indexes for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id_rating`);

--
-- Indexes for table `tahun_penilaian`
--
ALTER TABLE `tahun_penilaian`
  ADD PRIMARY KEY (`id_tahun_penilaian`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `id_level` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mutasi`
--
ALTER TABLE `mutasi`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=369;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
