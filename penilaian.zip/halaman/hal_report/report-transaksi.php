<link rel="stylesheet" href="assets/css/style.css" type="text/css">

<?php
session_start();
  include "../../config/koneksi.php";

// Apabila user belum login
if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser'])){
  echo "<h1>Untuk mengakses halaman, Anda harus login dulu.</h1><p><a href=\"index.php\">LOGIN</a></p>";  
}
// Apabila user sudah login dengan benar, maka terbentuklah session
else{
	 $db = new DB();
	 
	$th=$db->getRows('tahun_penilaian',array('where'=>array('id_tahun_penilaian'=>$_POST['tahun']),'return_type'=>'single'));
?>
<html>
<head>
<title> :: LAPORAN PENILAIAN BRANCH OUTLET</title>
<link href="halaman/hal_report/styles_cetak.css" rel="stylesheet" type="text/css">
</head>
<body>

	<center>
	<h2> LAPORAN PENILAIAN BRANCH OUTLET </h2>
	<p><?php echo"Periode : $th[nama_tahun_penilaian]";?></p>
	</center>
	<?php
	if($_POST['tahun'] !==''){
	$transaksi = $db->getRows('mutasi',array('where'=>array('id_tahun_penilaian'=>$_POST['tahun'])),array('order_by'=>'id_karyawan DESC'));
	}
	
	echo"<table class='table-list' width='100%' border='0' cellspacing='1' cellpadding='2'>
    <thead>
    <tr>
	<td bgcolor='#F5F5F5'>#</td>
	<td bgcolor='#F5F5F5' width='20%'>Nama Branch</td>
    <td bgcolor='#F5F5F5'>Average Rating</td>
    
    <td bgcolor='#F5F5F5'>Score  / Skor (Weighted  x Rating)</td>
    <td>Hasil Penilaian</td>
    <td>Predikat</td>
    </tr>
    </thead>
    <tbody>"; 
            
    $no = 1;
    // Tampilkan data tabel yang dipilih
    foreach($transaksi ? $transaksi : [] as $r){  extract($r);
	$k=$db->getRows('karyawan',array('where'=>array('id_karyawan'=>$id_karyawan),'return_type'=>'single'));
	$summ=$db->GetSumRating($id_karyawan,$_POST['tahun']);
	$weight=round($db->GetAverage2($id_karyawan,$_POST['tahun']),2);
	$skor=$db->GetSum();
	$hasil=$weight*$skor/50;

	if ($hasil <= 10) {
    $predikat = "<button class='btn btn-sm btn-primary'><div class='' style='color:white;'>Optimized</div> </div>";
} 	if ($hasil <= 8) {
    $predikat = "<button class='btn btn-sm btn-success'><div class='' style='color:white;'>Integrated</div> </div>";
}	if ($hasil <= 6) {
    $predikat = "<button class='btn btn-sm btn-warning'><div class='' style='color:white;'>Structured</div> </div>";
}	if ($hasil <= 4  ) {
    $predikat = "<button class='btn btn-sm btn-secondary'><div class='' style='color:white;'>Emergent</div> </div>";
}
if ($hasil <= 2 ) {
    $predikat = "<button class='btn btn-sm btn-danger'><div class='' style='color:white;'>Initial</div> </div>";
}
	//$avg=$db->GetAverage($yang_dinilai,$penilai,$id_tahun_penilaian);
    echo "
    <tr>
    <td class='center'>$no</td>
    <td class='center'>$k[nama_karyawan]</td>
    <td class='center'>".round($db->GetAverage2($id_karyawan,$_POST['tahun']),2)."</td>
    <td class='center'>".$db->GetSum()."</td>
    
    <td class='center'>$hasil</td>
    <td class='center'>$predikat</td>
   <td>
   
   </td>
    </tr>"; $no++;
    }
    echo"
	</tbody>
    </table>";
	?>
	</body>
	</html>
	<?php
	}
	?>
